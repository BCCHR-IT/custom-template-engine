<?php
/**
 * Create instance of Custom Template Engine, 
 * and upload image.
 */
$customTemplateEngine = new \BCCHR\CustomTemplateEngine\CustomTemplateEngine();
$customTemplateEngine->setPaths();
$customTemplateEngine->uploadImages();
