<?php
/**
 * Initialize Custom Template Engine object, and call method to download template.
 */
$customTemplateEngine = new \BCCHR\CustomTemplateEngine\CustomTemplateEngine();
$customTemplateEngine->setPaths();
$customTemplateEngine->downloadTemplate();
